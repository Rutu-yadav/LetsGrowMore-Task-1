import React from "react";

function Todolist(props) {
  return (
    <>
      <ul className="list-group">
        <li className="list-group-item">
          {props.item}
          <span className="icon">
            <i
              class="fa-solid fa-trash"
              onClick={(e) => {
                props.deleteItem(props.index);
              }}
            ></i>
          </span>
        </li>
      </ul>
    </>
  );
}

export default Todolist;
