import React, { useState } from "react";
import { Button } from "bootstrap";

function TodoInput(props) {
  const [inputText, setinputText] = useState("");
  const handleEnterKey = (e) => {
    if (e.keyCode === 13) {
      props.addlist(inputText);
      setinputText("");
    }
  };
  return (
    <div className="main">
      <div className="container">
        <input
          type="text"
          className="input-box"
          placeholder="Enter Todo Here..."
          value={inputText}
          onChange={(e) => {
            setinputText(e.target.value);
          }}
          onKeyDown={handleEnterKey}
        />
        <button
          className="btn btn-success"
          onClick={() => {
            props.addlist(inputText);
            setinputText("");
          }}
        >
          +
        </button>
        {/* <div>{inputText}</div> */}
      </div>
    </div>
  );
}

export default TodoInput;
