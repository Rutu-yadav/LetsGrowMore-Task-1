import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Todolist from "./Todolist";
import TodoInput from "./TodoInput";

function App() {
  const [listToDo, setlistToDO] = useState([]);

  let addlist = (inputText) => {
    if (inputText !== "") setlistToDO([...listToDo, inputText]);
  };

  const deleteItem = (key) => {
    let newlistTodo = [...listToDo];
    newlistTodo.splice(key, 1);
    setlistToDO([...newlistTodo]);
  };
  return (
    <>
      <div className="wrap">
        <h1 className="heading"> TO-DO-List</h1>
        <TodoInput addlist={addlist} />

        {listToDo.map((listitem, i) => {
          return (
            <Todolist
              key={i}
              index={i}
              item={listitem}
              deleteItem={deleteItem}
            />
          );
        })}
      </div>
    </>
  );
}

export default App;
